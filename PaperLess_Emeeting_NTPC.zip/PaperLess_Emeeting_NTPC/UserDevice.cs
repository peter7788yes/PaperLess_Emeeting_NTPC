public enum UserDevice
{
	PC = 1
}
