public enum DisplayUserNameMode
{
	None = 1,
	UserName,
	UserID_UserName
}
