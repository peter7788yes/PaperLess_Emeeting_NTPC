namespace PaperLess_Emeeting.App_Code.Socket
{
	public delegate void BroadcastCT_ClearList_Function();
}
