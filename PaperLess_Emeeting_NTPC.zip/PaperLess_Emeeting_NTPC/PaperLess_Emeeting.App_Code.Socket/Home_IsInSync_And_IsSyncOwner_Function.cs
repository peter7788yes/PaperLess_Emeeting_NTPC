using Newtonsoft.Json.Linq;

namespace PaperLess_Emeeting.App_Code.Socket
{
	public delegate void Home_IsInSync_And_IsSyncOwner_Function(JArray jArry);
}
