namespace PaperLess_Emeeting.App_Code.Socket
{
	public delegate void Home_TurnOffSyncButton_Function();
}
