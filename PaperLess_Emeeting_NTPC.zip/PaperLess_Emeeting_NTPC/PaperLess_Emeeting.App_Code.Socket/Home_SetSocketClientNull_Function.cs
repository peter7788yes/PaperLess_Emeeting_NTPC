namespace PaperLess_Emeeting.App_Code.Socket
{
	public delegate void Home_SetSocketClientNull_Function();
}
