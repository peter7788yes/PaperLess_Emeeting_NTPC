using Newtonsoft.Json.Linq;

namespace PaperLess_Emeeting.App_Code.Socket
{
	public delegate void MVWindow_IsInSync_And_IsSyncOwner_Function(JArray jArry);
}
