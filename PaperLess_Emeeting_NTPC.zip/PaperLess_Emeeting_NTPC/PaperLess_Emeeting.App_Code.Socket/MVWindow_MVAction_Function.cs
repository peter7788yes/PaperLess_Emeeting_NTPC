using Newtonsoft.Json.Linq;

namespace PaperLess_Emeeting.App_Code.Socket
{
	public delegate void MVWindow_MVAction_Function(JObject jObject);
}
