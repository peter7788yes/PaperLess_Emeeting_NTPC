namespace PaperLess_Emeeting.App_Code.Async
{
	public class AsyncTool
	{
		public AsyncTool()
		{
			AyncStart();
		}

		private void AyncStart()
		{
		}

		private void AyncPost()
		{
		}

		public void AyncEnd()
		{
		}
	}
}
