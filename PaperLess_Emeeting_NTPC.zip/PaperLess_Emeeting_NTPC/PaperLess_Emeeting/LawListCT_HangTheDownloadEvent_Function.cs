namespace PaperLess_Emeeting
{
	public delegate void LawListCT_HangTheDownloadEvent_Function(string LastLawItemID);
}
