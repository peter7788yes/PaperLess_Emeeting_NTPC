namespace PaperLess_Emeeting
{
	public delegate void showPenToolPanelEvent(bool isCanvasShowed);
}
