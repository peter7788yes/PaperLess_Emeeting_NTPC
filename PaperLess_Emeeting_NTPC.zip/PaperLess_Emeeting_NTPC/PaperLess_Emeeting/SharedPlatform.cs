namespace PaperLess_Emeeting
{
	public enum SharedPlatform
	{
		None,
		Facebook,
		Plurk,
		Mail,
		Google,
		Twitter
	}
}
