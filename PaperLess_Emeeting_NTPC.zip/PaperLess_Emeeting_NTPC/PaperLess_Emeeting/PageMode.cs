namespace PaperLess_Emeeting
{
	public enum PageMode
	{
		None,
		SinglePage,
		DoublePage
	}
}
