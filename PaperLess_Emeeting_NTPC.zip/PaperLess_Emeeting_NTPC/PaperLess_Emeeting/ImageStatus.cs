namespace PaperLess_Emeeting
{
	public enum ImageStatus
	{
		UNKNOWN,
		SMALLIMAGE,
		LARGEIMAGE,
		GENERATING
	}
}
