using System.Windows.Ink;

namespace PaperLess_Emeeting
{
	public delegate void StrokeChangeEvent(DrawingAttributes d);
}
