namespace PaperLess_Emeeting
{
	public delegate void Home_Change2MeetingDataCT_Function(string MeetingID, MeetingData meetingData = null);
}
