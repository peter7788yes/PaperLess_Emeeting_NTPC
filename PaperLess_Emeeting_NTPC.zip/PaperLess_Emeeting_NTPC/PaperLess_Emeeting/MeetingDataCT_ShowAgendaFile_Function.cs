namespace PaperLess_Emeeting
{
	public delegate void MeetingDataCT_ShowAgendaFile_Function(string AgendaID, string ParentID, bool IsDbClick);
}
