using System;

namespace PaperLess_Emeeting
{
	public delegate Tuple<bool, bool> Home_ReturnSyncStatus_Function();
}
