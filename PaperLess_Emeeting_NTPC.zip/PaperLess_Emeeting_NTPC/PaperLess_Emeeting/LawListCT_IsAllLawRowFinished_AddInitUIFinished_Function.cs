namespace PaperLess_Emeeting
{
	public delegate bool LawListCT_IsAllLawRowFinished_AddInitUIFinished_Function();
}
