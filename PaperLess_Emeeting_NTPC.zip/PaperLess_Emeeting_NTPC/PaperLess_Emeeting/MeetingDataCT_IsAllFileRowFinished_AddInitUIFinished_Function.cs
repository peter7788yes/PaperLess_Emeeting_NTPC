namespace PaperLess_Emeeting
{
	public delegate bool MeetingDataCT_IsAllFileRowFinished_AddInitUIFinished_Function();
}
