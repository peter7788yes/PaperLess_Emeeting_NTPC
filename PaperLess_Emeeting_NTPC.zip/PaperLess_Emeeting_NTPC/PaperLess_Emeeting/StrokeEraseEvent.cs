namespace PaperLess_Emeeting
{
	public delegate void StrokeEraseEvent();
}
