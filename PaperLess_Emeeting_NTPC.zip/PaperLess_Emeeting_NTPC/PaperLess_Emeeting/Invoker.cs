namespace PaperLess_Emeeting
{
	internal delegate void Invoker();
}
