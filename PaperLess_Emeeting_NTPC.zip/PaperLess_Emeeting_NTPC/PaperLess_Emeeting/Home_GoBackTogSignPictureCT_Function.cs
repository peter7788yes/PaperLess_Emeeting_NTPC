namespace PaperLess_Emeeting
{
	public delegate void Home_GoBackTogSignPictureCT_Function(string DeptID, string PicUrl);
}
