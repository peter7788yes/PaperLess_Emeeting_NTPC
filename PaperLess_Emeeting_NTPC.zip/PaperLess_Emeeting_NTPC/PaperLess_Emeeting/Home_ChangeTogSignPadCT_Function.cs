namespace PaperLess_Emeeting
{
	public delegate void Home_ChangeTogSignPadCT_Function(string UserID, string UserName);
}
