namespace PaperLess_Emeeting
{
	public delegate void Home_PopUpButtons_Function(string ButtonID);
}
