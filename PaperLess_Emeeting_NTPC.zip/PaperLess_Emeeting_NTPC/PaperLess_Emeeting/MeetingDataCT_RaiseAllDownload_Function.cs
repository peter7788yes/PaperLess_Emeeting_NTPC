namespace PaperLess_Emeeting
{
	public delegate void MeetingDataCT_RaiseAllDownload_Function(string LastFileItemID, bool IsAutoUpdate, bool DoNotChangeAlready_RaiseAllDownload);
}
