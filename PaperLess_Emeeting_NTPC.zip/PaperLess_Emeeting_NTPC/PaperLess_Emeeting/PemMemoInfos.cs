using System.Runtime.CompilerServices;

namespace PaperLess_Emeeting
{
	public class PemMemoInfos
	{
		[CompilerGenerated]
		private double _003CcanvasWidth_003Ek__BackingField;

		[CompilerGenerated]
		private double _003CcanvasHeight_003Ek__BackingField;

		[CompilerGenerated]
		private double _003CstrokeAlpha_003Ek__BackingField;

		[CompilerGenerated]
		private string _003Cpoints_003Ek__BackingField;

		[CompilerGenerated]
		private string _003CstrokeColor_003Ek__BackingField;

		[CompilerGenerated]
		private double _003CstrokeWidth_003Ek__BackingField;

		public double canvasWidth
		{
			[CompilerGenerated]
			get
			{
				return _003CcanvasWidth_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003CcanvasWidth_003Ek__BackingField = value;
			}
		}

		public double canvasHeight
		{
			[CompilerGenerated]
			get
			{
				return _003CcanvasHeight_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003CcanvasHeight_003Ek__BackingField = value;
			}
		}

		public double strokeAlpha
		{
			[CompilerGenerated]
			get
			{
				return _003CstrokeAlpha_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003CstrokeAlpha_003Ek__BackingField = value;
			}
		}

		public string points
		{
			[CompilerGenerated]
			get
			{
				return _003Cpoints_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003Cpoints_003Ek__BackingField = value;
			}
		}

		public string strokeColor
		{
			[CompilerGenerated]
			get
			{
				return _003CstrokeColor_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003CstrokeColor_003Ek__BackingField = value;
			}
		}

		public double strokeWidth
		{
			[CompilerGenerated]
			get
			{
				return _003CstrokeWidth_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003CstrokeWidth_003Ek__BackingField = value;
			}
		}
	}
}
