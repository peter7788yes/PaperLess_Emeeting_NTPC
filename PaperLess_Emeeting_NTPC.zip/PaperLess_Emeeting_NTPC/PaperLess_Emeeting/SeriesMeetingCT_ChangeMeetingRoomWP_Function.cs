namespace PaperLess_Emeeting
{
	public delegate void SeriesMeetingCT_ChangeMeetingRoomWP_Function(string SeriesID);
}
