using PaperLess_ViewModel;

namespace PaperLess_Emeeting
{
	public delegate void Home_ChangeBtnSP_Function(UserButton[] UserButtonAry, string ActiveButtonID);
}
