namespace PaperLess_Emeeting
{
	public enum MediaCanvasOpenedBy
	{
		None,
		SearchButton,
		MediaButton,
		CategoryButton,
		NoteButton,
		ShareButton,
		SettingButton,
		PenMemo
	}
}
