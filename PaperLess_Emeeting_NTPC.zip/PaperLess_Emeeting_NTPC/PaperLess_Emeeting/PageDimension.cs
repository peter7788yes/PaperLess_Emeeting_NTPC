namespace PaperLess_Emeeting
{
	public struct PageDimension
	{
		public double w;

		public double h;
	}
}
