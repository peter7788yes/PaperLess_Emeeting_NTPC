namespace PaperLess_Emeeting
{
	public delegate void Home_ChangeCC_Function(string ButtonID);
}
