namespace PaperLess_Emeeting
{
	public delegate void MeetingDataCT_Counting_Finished_FileCount_Function();
}
