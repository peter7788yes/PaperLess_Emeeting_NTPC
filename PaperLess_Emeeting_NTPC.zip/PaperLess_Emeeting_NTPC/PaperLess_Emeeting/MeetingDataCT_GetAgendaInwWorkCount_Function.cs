namespace PaperLess_Emeeting
{
	public delegate int MeetingDataCT_GetAgendaInwWorkCount_Function(string AgendaID);
}
