namespace PaperLess_Emeeting
{
	public delegate string MeetingDataCT_GetWatermark_Function();
}
