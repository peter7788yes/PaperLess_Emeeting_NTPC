namespace PaperLess_Emeeting
{
	public delegate void MeetingList_Show_HiddenMeetingDayList_Function();
}
