namespace PaperLess_Emeeting
{
	public delegate void MeetingDataCT_HangTheDownloadEvent_Function(string LastFileItemID);
}
