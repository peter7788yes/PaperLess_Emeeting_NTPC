public enum LawDataStatus
{
	無效,
	有效
}
