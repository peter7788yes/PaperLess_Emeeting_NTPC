public enum PDFStatus
{
	尚未匯出,
	匯出成功,
	匯出中,
	等待中
}
