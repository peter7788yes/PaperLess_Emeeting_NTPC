using System.CodeDom.Compiler;

namespace PaperLess_Emeeting.WS
{
	[GeneratedCode("System.Web.Services", "4.0.30319.18408")]
	public delegate void SeriesDataCompletedEventHandler(object sender, SeriesDataCompletedEventArgs e);
}
