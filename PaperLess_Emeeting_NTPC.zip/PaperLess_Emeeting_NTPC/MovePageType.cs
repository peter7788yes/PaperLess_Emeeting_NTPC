public enum MovePageType
{
	上一頁 = 1,
	下一頁,
	第一頁,
	最後一頁
}
