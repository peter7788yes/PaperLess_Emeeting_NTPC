public enum DownloaderType
{
	沒有任何檔案下載中 = 0,
	正在下載中 = 2,
	暫停 = 3,
	停止 = 4,
	檔案下載完成 = 5,
	下載出錯 = 6
}
