public enum MeetingRoomButtonType
{
	NN = 1,
	NY,
	NO,
	YN,
	YY,
	YO,
	ON,
	OY,
	OO
}
