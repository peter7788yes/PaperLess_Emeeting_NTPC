public enum MeetingUserType
{
	議事管理人員 = 1,
	與會人員,
	代理人,
	其它
}
