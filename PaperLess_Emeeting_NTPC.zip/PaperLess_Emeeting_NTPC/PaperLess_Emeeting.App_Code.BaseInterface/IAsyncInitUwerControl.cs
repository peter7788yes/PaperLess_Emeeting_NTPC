namespace PaperLess_Emeeting.App_Code.BaseInterface
{
	internal interface IAsyncInitUwerControl
	{
		void InitSelectDB();

		void InitEvent();

		void InitUI();
	}
}
