namespace PaperLess_Emeeting.App_Code.WS
{
	public delegate void Home_UnZipError_Function(string message);
}
