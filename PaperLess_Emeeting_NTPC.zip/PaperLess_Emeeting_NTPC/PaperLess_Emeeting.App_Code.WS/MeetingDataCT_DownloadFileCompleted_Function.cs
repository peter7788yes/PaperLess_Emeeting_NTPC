using PaperLess_Emeeting.App_Code.DownloadItem;

namespace PaperLess_Emeeting.App_Code.WS
{
	public delegate void MeetingDataCT_DownloadFileCompleted_Function(File_DownloadItemViewModel obj);
}
