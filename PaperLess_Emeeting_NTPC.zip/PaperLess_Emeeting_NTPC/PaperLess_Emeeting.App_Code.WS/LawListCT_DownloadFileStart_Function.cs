using PaperLess_Emeeting.App_Code.DownloadItem;

namespace PaperLess_Emeeting.App_Code.WS
{
	public delegate void LawListCT_DownloadFileStart_Function(Law_DownloadItemViewModel obj);
}
