public enum AgendaFilter
{
	顯示全部附件 = 1,
	顯示父議題和子議題附件,
	顯示當前議題附件
}
