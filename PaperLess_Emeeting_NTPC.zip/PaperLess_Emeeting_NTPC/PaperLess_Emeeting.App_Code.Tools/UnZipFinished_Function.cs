namespace PaperLess_Emeeting.App_Code.Tools
{
	public delegate void UnZipFinished_Function();
}
