namespace PaperLess_Emeeting.App_Code.Tools
{
	public delegate void UnZipError_Function();
}
