using System.Runtime.CompilerServices;

namespace PaperLess_Emeeting.App_Code
{
	public class PDFFactoryParameter
	{
		[CompilerGenerated]
		private bool _003CisHtml_003Ek__BackingField;

		[CompilerGenerated]
		private string _003CbookPath_003Ek__BackingField;

		[CompilerGenerated]
		private int _003CtotalPage_003Ek__BackingField;

		[CompilerGenerated]
		private float _003Cwidth_003Ek__BackingField;

		[CompilerGenerated]
		private float _003Cheight_003Ek__BackingField;

		[CompilerGenerated]
		private string _003CUserAccount_003Ek__BackingField;

		[CompilerGenerated]
		private string _003CbookId_003Ek__BackingField;

		[CompilerGenerated]
		private string _003CdbPath_003Ek__BackingField;

		[CompilerGenerated]
		private string _003CthumbsPath_Msize_003Ek__BackingField;

		[CompilerGenerated]
		private string _003CthumbsPath_Lsize_003Ek__BackingField;

		[CompilerGenerated]
		private int _003Ccounter_003Ek__BackingField;

		public bool isHtml
		{
			[CompilerGenerated]
			get
			{
				return _003CisHtml_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003CisHtml_003Ek__BackingField = value;
			}
		}

		public string bookPath
		{
			[CompilerGenerated]
			get
			{
				return _003CbookPath_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003CbookPath_003Ek__BackingField = value;
			}
		}

		public int totalPage
		{
			[CompilerGenerated]
			get
			{
				return _003CtotalPage_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003CtotalPage_003Ek__BackingField = value;
			}
		}

		public float width
		{
			[CompilerGenerated]
			get
			{
				return _003Cwidth_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003Cwidth_003Ek__BackingField = value;
			}
		}

		public float height
		{
			[CompilerGenerated]
			get
			{
				return _003Cheight_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003Cheight_003Ek__BackingField = value;
			}
		}

		public string UserAccount
		{
			[CompilerGenerated]
			get
			{
				return _003CUserAccount_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003CUserAccount_003Ek__BackingField = value;
			}
		}

		public string bookId
		{
			[CompilerGenerated]
			get
			{
				return _003CbookId_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003CbookId_003Ek__BackingField = value;
			}
		}

		public string dbPath
		{
			[CompilerGenerated]
			get
			{
				return _003CdbPath_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003CdbPath_003Ek__BackingField = value;
			}
		}

		public string thumbsPath_Msize
		{
			[CompilerGenerated]
			get
			{
				return _003CthumbsPath_Msize_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003CthumbsPath_Msize_003Ek__BackingField = value;
			}
		}

		public string thumbsPath_Lsize
		{
			[CompilerGenerated]
			get
			{
				return _003CthumbsPath_Lsize_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003CthumbsPath_Lsize_003Ek__BackingField = value;
			}
		}

		public int counter
		{
			[CompilerGenerated]
			get
			{
				return _003Ccounter_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003Ccounter_003Ek__BackingField = value;
			}
		}
	}
}
